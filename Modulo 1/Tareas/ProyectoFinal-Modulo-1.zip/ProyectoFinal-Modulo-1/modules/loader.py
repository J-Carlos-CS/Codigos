"""
Este módulo contiene funciones para cargar imágenes desde el dataset de Kaggle.
"""

import os
import shutil
from kagglehub import kagglehub
import pandas as pd
import cv2
from tqdm.auto import tqdm

from models.image import Image


def cargar_datos():
    """
    Carga las imágenes desde el dataset de Kaggle.
    Retorna una lista de objetos Image.
    """
    images = []

    dataset_dir = "./data/dataset"
    asegurar_descarga_dataset(dataset_dir)

    for category_dir in os.listdir(dataset_dir):
        category_path = os.path.join(dataset_dir, category_dir)
        if os.path.isdir(category_path):
            image_dir = os.path.join(category_path, "images")
            if os.path.exists(image_dir):
                for image_filename in tqdm(
                    os.listdir(image_dir), desc=f"Processing {category_dir}"
                ):
                    image_path = os.path.join(image_dir, image_filename)
                    if os.path.isfile(image_path):
                        try:
                            image_size = os.path.getsize(image_path)
                            img = cv2.imread(image_path)
                            if img is not None:
                                height, width, _ = img.shape
                                image_dimensions = f"{width}x{height}"
                            else:
                                height, width = None, None
                                image_dimensions = None
                            image_format = os.path.splitext(image_filename)[1]
                            images.append(
                                Image(
                                    image_path,
                                    image_size,
                                    image_dimensions,
                                    width,
                                    height,
                                    image_filename,
                                    category_dir,
                                    image_format,
                                )
                            )
                        except Exception as e:
                            print(f"Error processing image {image_path}: {e}")
    print(f"✅ Se cargaron {len(images)} imágenes del dataset.")
    return images


def asegurar_descarga_dataset(path_to_save):
    """
    Descarga el dataset de Kaggle y lo guarda en la carpeta deseada.
    """
    try:
        if not os.path.exists(path_to_save):
            dataset_path = kagglehub.dataset_download(
                "tawsifurrahman/covid19-radiography-database", force_download=True
            )
            extracted_path = os.path.join(dataset_path, "COVID-19_Radiography_Dataset")
            print(f"Extracted path {extracted_path}")

            if os.path.exists(extracted_path):
                os.makedirs("data", exist_ok=True)
                shutil.move(extracted_path, path_to_save)
                print(f"✅ Dataset descargado y disponible en: {path_to_save}")
            else:
                raise FileNotFoundError(
                    "❌ No se encontró la carpeta del dataset extraído."
                )
        else:
            print("📁 Dataset ya existe localmente.")

    except ImportError:
        print(
            "Error: kagglehub no está instalado. Por favor, instálalo para cargar el dataset."
        )
        return []
