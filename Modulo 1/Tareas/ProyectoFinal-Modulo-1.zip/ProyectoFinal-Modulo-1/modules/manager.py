"""
Métodos para  registrar_imagen, modificar_imagen, eliminar_imagen
"""

from concurrent.futures import thread
import random
import cv2
import threading
from models.image import Image
import os


class ImgenesManager:
    def __init__(self):
        self.imagenes = {}

    def agregar_imagen(self, valor):
        """
            Funcion para agregar una imagen.
        """
        if valor.file_name in self.imagenes:
            raise ValueError(f"La clave '{valor.file_name}' ya existe.")
        self.imagenes[valor.file_name] = valor

    def mostrar(self):
        """
            Funcion para mostrar todos los elementos de la lista.
        """
        for k, v in self.imagenes.items():
            print(f"{k}: {v}")

    def mostrar_imagen(self, file_name):
        """
            Funcion para mostrar una imagen segun el nombre.
        """
        if file_name in self.imagenes:
            path_image = self.imagenes[file_name].file_path
            thread = threading.Thread(target=self.imprimirImagen, args=(path_image,))
            thread.start()
        else:
            print(f"No se encontró la imagen con el nombre: {file_name}")

    def mostrar_random_Image(self):
        """
            Funcion para mostrar una imagen aleatoria.
        """
        if not self.imagenes:
            print("No hay imágenes registradas.")
            return None
        random_key = random.choice(list(self.imagenes.keys()))
        random_image = self.imagenes[random_key]
        path_image = random_image.file_path
        thread = threading.Thread(target=self.imprimirImagen, args=(path_image,))
        thread.start()

    def imprimirImagen(self, path_image):
        """
            Funcion para imprimir una imagen desde un path.
        """
        imagen = cv2.imread(path_image)
        cv2.imshow("Imagen", imagen)
        cv2.waitKey(0)

    def modificar_imagen(self, file_name, new_image):
        """
            Funcion para modificar una imagen.
        """
        if file_name in self.imagenes:
            self.imagenes[file_name].file_path = new_image
            print(f"La direccion de la imagen '{file_name}' ha sido actualizada.")
        else:
            print(f"No se encontró la imagen con el nombre: {file_name}")

    def eliminar_imagen(self, file_name):
        """
            Funcion para eliminar una imagen desde un nombre de imagen.
        """
        if file_name in self.imagenes:
            del self.imagenes[file_name]
            print(f"Imagen '{file_name}' eliminada.")
        else:
            print(f"No se encontró la imagen con el nombre: {file_name}")

    def cargar_imagenes(self, path_imagen, categoria):
        """
            Funcion para cargar una imagen dsede su path.
        """
        if not os.path.exists(path_imagen):
            print(f"No se encontró la imagen en la ruta: {path_imagen}")
            return

        imagen = cv2.imread(path_imagen)
        if imagen is None:
            print(f"No se pudo cargar la imagen: {path_imagen}")
            return

        height, width = imagen.shape[:2]
        image_size = os.path.getsize(path_imagen)
        image_dimensions = f"{width}x{height}"
        image_filename = os.path.basename(path_imagen)
        category_dir = categoria
        _, image_format = os.path.splitext(image_filename)
        image_format = image_format.lstrip(".").upper()

        nueva_imagen = Image(
            path_imagen,
            image_size,
            image_dimensions,
            width,
            height,
            image_filename,
            category_dir,
            image_format,
        )
        print(f"Imagen cargada: {nueva_imagen}")
        self.agregar_imagen(nueva_imagen)
