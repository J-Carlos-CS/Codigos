"""
Módulo principal del sistema de gestión de imágenes médicas.
Muestra el menú principal e invoca las funcionalidades según la opción seleccionada.
"""

import sys
from tkinter import Tk, filedialog
from modules.loader import cargar_datos
from modules.manager import ImgenesManager


def mostrar_menu():
    """
    Muestra el menú principal del sistema.
    """
    print("\n--- MENÚ PRINCIPAL ---")
    print("1. Registrar una nueva imagen")
    print("2. Ver imágen")
    print("3. Ver imagen aleatoria")
    print("4. Modificar imagen existente")
    print("5. Eliminar imagen")
    print("6. Salir")


def main():
    """
    Función principal que inicia el sistema de gestión de imágenes médicas.
    """
    #  Precarga del dataset
    imagenes = cargar_datos()
    manager = ImgenesManager()
    for img in imagenes:
        manager.agregar_imagen(img)
    while True:
        mostrar_menu()
        opcion = input("Seleccione una opción (1-6): ").strip()
        if opcion == "1":
            # Inicializa tkinter sin abrir ventana
            root = Tk()
            root.withdraw()
            root.update()  # Asegura que el diálogo se renderice bien
            # Abre el selector de archivos
            ruta_imagen = filedialog.askopenfilename(
                title="Selecciona una imagen",
                filetypes=[("Imágenes", "*.jpg *.png *.bmp *.tiff *.gif")],
            )
            root.destroy()
            file_name = input("Ingrese la categoria de la imagen: ").strip()
            manager.cargar_imagenes(ruta_imagen, file_name)
        elif opcion == "2":
            file_name = input("Ingrese el nombre del archivo de la imagen: ").strip()
            manager.mostrar_imagen(file_name)
        elif opcion == "3":
            manager.mostrar_random_Image()
        elif opcion == "4":
            file_name = input(
                "Ingrese el nombre del archivo de la imagen a modificar: "
            ).strip()
            new_image = input("Ingrese la nueva ruta de la imagen: ").strip()
            manager.modificar_imagen(file_name, new_image)
        elif opcion == "5":
            file_name = input(
                "Ingrese el nombre del archivo de la imagen a eliminar: "
            ).strip()
            manager.eliminar_imagen(file_name)
        elif opcion == "6":
            print("Saliendo del sistema. ¡Hasta luego!")
            sys.exit()
        else:
            print("Opción no válida. Por favor, intente de nuevo.")


if __name__ == "__main__":
    main()
