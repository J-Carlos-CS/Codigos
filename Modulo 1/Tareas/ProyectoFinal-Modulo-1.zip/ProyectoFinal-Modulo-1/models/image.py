"""
Este módulo define la clase `Image` que representa una imagen con sus atributos básicos.
"""


class Image:
    """
    Clase que representa una imagen con sus atributos básicos.
    """

    def __init__(
        self,
        file_path,
        size_bytes,
        dimensions,
        width,
        height,
        file_name,
        category,
        image_format,
    ):
        self.file_path = file_path
        self.size_bytes = size_bytes
        self.dimensions = dimensions
        self.width = width
        self.height = height
        self.file_name = file_name
        self.category = category
        self.image_format = image_format

    def __str__(self):
        return f"""Image(file_path={self.file_path}, size_bytes={self.size_bytes}, dimensions={self.dimensions}, width={self.width}, height={self.height}, file_name={self.file_name}, category={self.category}, format={self.image_format})"""
