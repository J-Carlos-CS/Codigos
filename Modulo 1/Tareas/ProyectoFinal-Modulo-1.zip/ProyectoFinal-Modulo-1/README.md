# Proyecto Final 
## Fundamentos de Ingeniería de Software para Científicos de Datos - MIAV1E4

### Integrantes
- Adrian Fernandez
- Aldo Balderrama
- Christian Flores
- Jose Gutierrez
- Carlos Camacho

## Desarrollo

A partir del dataset COVID-19 [Radiography Database](https://www.kaggle.com/datasets/tawsifurrahman/covid19-radiography-database) se desarollo un programa que permite agregar nuevas imagenes al dataset, las cuales son clasificadas como COVID-19, Normal o Pneumonia.

## Requisitos

- Python 3.11
- Conda o Miniconda instalado

## Configuración del entorno

```bash
conda create -n master_modulo1 python=3.13 -y
conda activate master_modulo1
pip install -r requirements.txt
```

## Descargar Dataset
El dataset se descarga desde kaggle automaticamente al ejecutar el programa por primera vez. Si se desea descargar manualmente, se puede hacer desde la página de Kaggle y colocar el dataset en la carpeta `data/dataset`.

Asegurese de tener el archivo `kaggle.json` en la carpeta `~/.kaggle/` con las credenciales de su cuenta de Kaggle.

## Iniciar el programa
Para iniciar el programa, ejecute el siguiente comando:

```bash
python main.py
```

## Diagrama
![PHOTO-2025-08-06-23-48-15](https://github.com/user-attachments/assets/b8b98c2d-8e1b-460c-a39a-2275fbc8c883)


